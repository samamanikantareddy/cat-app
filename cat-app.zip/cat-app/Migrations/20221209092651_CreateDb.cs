﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace cat_app.Migrations
{
    public partial class CreateDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
